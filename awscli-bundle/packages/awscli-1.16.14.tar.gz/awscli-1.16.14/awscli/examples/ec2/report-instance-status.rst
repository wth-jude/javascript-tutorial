**To report status feedback for an instance**

This example command reports status feedback for the specified instance.

Command::

  aws ec2 report-instance-status --instances i-1234567890abcdef0 --status impaired --reason-codes unresponsive
